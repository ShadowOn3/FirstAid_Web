"""Controladores de páginas."""

# App
from app import app

# Flask
from flask import render_template

@app.route("/", methods=["GET"])
def index():
    """Página de inicio"""
    return render_template("pages/index.html")

@app.route("/nosotros/", methods=["GET"])
def nosotros():
    """Página de nosotros."""
    return render_template("pages/nosotros.html")

@app.route("/cursos/", methods=["GET"])
def cursos():
    """Página de cursos."""
    return render_template("pages/cursos.html")

@app.route("/charlas/", methods=["GET"])
def charlas():
    """Página de charlas."""
    return render_template("pages/charlas.html")

@app.route("/talleres/", methods=["GET"])
def talleres():
    """Página de talleres."""
    return render_template("pages/talleres.html")

@app.route("/perfil/", methods=["GET"])
def perfil():
    """Página de perfil."""
    return render_template("pages/perfil.html")

