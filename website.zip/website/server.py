"""Server app."""

# Importar la aplicación
from app import app

# Controladores de la página
from app.controllers.pages import (
    index,
    nosotros,
    cursos,
    charlas,
    talleres,
    perfil
)

# Ejecutar el servidor
if __name__ == "__main__":
    app.run(debug=True, port=5000)